﻿#!/bin/bash

logfile=test-hardware-$(date '+%F-%T').log

# Установка зависимостей
echo '===== Установка зависимостей ====='
dnf install -y -q test/*
dnf install -y inxi stress-ng lsscsi p7zip
echo 'Оk'

echo '===== CPU group test ====='
echo 'lscpu test'
echo '===== lscpu =====' >> $logfile
lscpu >> $logfile
echo '=================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'stress-ng cpu test'
echo '===== stress-ng cpu =====' >> $logfile
stress-ng --cpu 0 -t 90 --metrics-brief &>>$logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'sensors test'
echo '===== sensors =====' >> $logfile
sensors &>>$logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== RAM group test ====='
echo 'free test'
echo '===== free =====' >> $logfile
free -h >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'dmidecode test'
echo '===== dmidecode memory =====' >> $logfile
dmidecode --type memory >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'stress-ng ram test'
echo '===== stress-ng ram test =====' >> $logfile
stress-ng --sequential 0 --class memory --timeout 60s --metrics-brief &>>$logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== Storage group test ====='
echo 'All disk list test'
echo '===== disk list =====' >> $logfile
ls -l /dev | grep -E 'sd|hd' >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'All mounted volume test'
echo '===== mounted volumes =====' >> $logfile
df -h >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'All storage SMART test'
echo '===== SMART =====' >> $logfile
for i in `smartctl --scan-open | grep "/dev/sd" | awk '{print $1}'`
do
echo ' SMART for '$i >> $logfile
smartctl --info $i >> $logfile
done
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'Disk speed'
echo '===== all disk speed =====' >> $logfile
for i in `smartctl --scan-open | grep "/dev/sd" | awk '{print $1}'`
do
echo ' Speed for '$i >> $logfile
hdparm -Tt $i >> $logfile
done
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== PCI group test ====='
echo 'PCI test'
echo '===== lspci =====' >> $logfile
lspci >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'
echo 'PCI drivers test'
echo '===== lspci drivers =====' >> $logfile
lspci -k >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== SCSI group test ====='
echo 'SCSI test'
echo '===== lsscsi =====' >> $logfile
lsscsi >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== USB group test ====='
echo 'USB test'
echo '===== lsusb =====' >> $logfile
lsusb >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '===== Other group test ====='

echo 'All hardware list test'
echo '===== lnxi =====' >> $logfile
inxi -Fxxx &>>$logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo '7Zip benchmark test'
echo '===== 7zip =====' >> $logfile
7za b -mm=* >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'Network test'
echo '===== mtr =====' >> $logfile
mtr -rw -c 3 `ip route | grep default | awk '{print $3}'` >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'

echo 'DMI test'
echo '===== dmi =====' >> $logfile
dmidecode >> $logfile
echo '=========================' >> $logfile
echo '' >> $logfile
echo 'Ok'
