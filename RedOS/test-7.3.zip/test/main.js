var $post_masonry = $('.projects__items');
$(document).ready(function () {
    if ($post_masonry.length) {
        var $masonry = $post_masonry.imagesLoaded(function () {
            $masonry.isotope({
                percentPosition: true,
                itemSelector: '.projects__item',
                layoutMode: 'masonry',

            });
        });
    }
}); 